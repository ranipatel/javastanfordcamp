
package person;

public class Person {

   
    public static void main(String[] args) {
        int age = 22;
        double height = 5.1;
        String firstName = "Alix";
        String lastName = "Feinsod";
        boolean isAStudent = false;
        
        String hairColor = "Pink";
        int faveNumber=22;
        
        System.out.println("My name is " + firstName + " " + lastName + ". " +
                "I am " + age + "and I am " + height + " tall. ");
        System.out.println("I am a student: " + isAStudent);
        System.out.println("My hair is " + hairColor + " and my favorite number is " + faveNumber);

        
    }
    
}
