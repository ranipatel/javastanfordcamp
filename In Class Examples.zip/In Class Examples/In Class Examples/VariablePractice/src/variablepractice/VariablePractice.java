
package variablepractice;

public class VariablePractice {

   
    public static void main(String[] args) {
        int a=8;
        int b=3;
        int c=1;
        int x,y,z;
        double pi=3.14159265;
        boolean isSummer=true;
        boolean wearingHat=false;
        String morning = "Good morning, class!";
        String afternoon = "Good afternoon, class!";
        
        int d= a+b;
        System.out.println(d);
        System.out.println("d");
        
         System.out.println(morning);
         
         System.out.println("a = " + a);
    }
    
}
