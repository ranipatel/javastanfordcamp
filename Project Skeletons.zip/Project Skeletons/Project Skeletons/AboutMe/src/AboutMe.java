public class AboutMe {

   public static void main(String[] args) {
      System.out.println("My name is Alix, 22 years old, from Berkeley, CA.");
      System.out.println("I love to sew and deisgn clothes, I'm a musical theater fan, and I read a ton!");
      System.out.println("My favorite color is purple.");
   }
}